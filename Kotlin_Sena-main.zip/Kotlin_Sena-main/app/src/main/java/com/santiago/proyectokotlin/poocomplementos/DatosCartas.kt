package com.santiago.proyectokotlin.poocomplementos

enum class DatosCartas() {
    DIAMANTE,
    TREBOL,
    CORAZON,
    PICAS
}