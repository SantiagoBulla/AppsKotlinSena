package com.santiago.proyectokotlin.poocomplementos

fun main() {
//    val producto1 = Producto(1, "leche", 5000.0)
//    val producto2 = Producto(2, "pan", 2000.0)
//    println(producto1)
//    println(producto2)
//    val seleccion = producto1
//    seleccion.precio = 5500.0
//    println(producto1)
//    var producto3 = producto2.copy()
//    producto3.precio = 3000.0
//    producto3.codigo = 3

    println("El valor de PI es: ${Matematicas.PI}")
    println("Un valor aleatorio entre 1 y 180")
    println(Matematicas.aleatorio(1,180))
}

