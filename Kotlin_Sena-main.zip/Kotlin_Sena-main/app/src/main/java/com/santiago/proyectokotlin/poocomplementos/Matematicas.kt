package com.santiago.proyectokotlin.poocomplementos

object Matematicas {
    val PI = 3.1416

    fun aleatorio(min: Int, max: Int) =((Math.random() * (max + 1 - min ))+min).toInt()

}