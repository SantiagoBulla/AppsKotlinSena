package com.santiago.proyectokotlin.poocoloaboracion

fun main() {
    val bancoBBVA: Banco = Banco()
    bancoBBVA.movimientos()
    bancoBBVA.estadoCuenta()
}