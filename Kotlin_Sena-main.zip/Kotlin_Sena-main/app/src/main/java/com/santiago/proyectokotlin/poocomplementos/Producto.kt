package com.santiago.proyectokotlin.poocomplementos

data class Producto(var codigo:Int , var descripcion:String, var precio:Double)